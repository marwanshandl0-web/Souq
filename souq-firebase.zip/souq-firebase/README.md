# نشر متجر سوق الحي

1. في Firebase Console (مشروع souq-elhay):
   - Build > Authentication > Get started > فعّل Google.
   - Build > Firestore Database > Create database.
2. غيّر marwanshandl0@gmail.com لإيميل الإدارة في مكانين:
   - public/index.html (ADMIN_EMAILS)
   - firestore.rules
3. من الترمنال داخل المجلد:
   npm i -g firebase-tools
   firebase login
   firebase deploy
4. افتح https://souq-elhay.web.app وادخل بحساب الإدارة.
